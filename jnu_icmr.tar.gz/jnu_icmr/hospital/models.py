from statistics import mode
from django.db import models

class Patient_Details(models.Model):
    patient_id=models.AutoField(primary_key=True)
    patient_in_quarantine_facility=models.CharField(max_length=225)
    present_village_town=models.CharField(max_length=225)
    district_of_present_residence=models.CharField(max_length=225)
    pincode=models.IntegerField()
    age=models.IntegerField()
    gender=models.CharField(max_length=225)
    nationality=models.CharField(max_length=225)
    class Meta:
        db_table='patient'

class Hospitalization_Details(models.Model):
    hospital_id=models.AutoField(primary_key=True)
    hospitalization_date=models.DateField()
    hospital_state=models.CharField(max_length=225)
    hospital_district=models.CharField(max_length=225)
    hospital_name=models.CharField(max_length=225)
    class Meta:
        db_table='hosptal'