from django.shortcuts import render

# login page code start

def loginpro(request):
    return render(request,'login.html')


# login page code end

# home page start 
def home(request):
    return render(request,'homePage.html')
# home page end 


